package com.ashika.data.response;

public class FinarkeinResponse {
	private String requestId;
	private String consentHandle;

	// Getters and setters
	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getConsentHandle() {
		return consentHandle;
	}

	public void setConsentHandle(String consentHandle) {
		this.consentHandle = consentHandle;
	}
}
